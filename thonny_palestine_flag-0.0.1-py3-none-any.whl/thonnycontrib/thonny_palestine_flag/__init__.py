from thonny.languages import tr
import os
from thonny import get_workbench
import webbrowser


def load_plugin() -> None:

    w=get_workbench()
    # w.add_command(
    #         "SupportPalestine",
    #         "help",
    #         "Support Palestine",
    #         _support_palestine,
    #         image= os.path.join(os.path.dirname(__file__), "res", "Palestine.png"),
    #         caption="Support",
    #         include_in_toolbar=True,
    #         group=101,
    #     )
    

    w.add_command(
        
        
         "SupportPalestine",
         "help",
         "SupportPalestine",
        handler= _support_palestine,
        image= os.path.join(os.path.dirname(__file__), "res", "Palestine.png"),
        caption="Palestine",
        include_in_toolbar=True,
        group=99,
    )
    w.after_idle(_unsupport_ukraine)
    #w._publish_commands()



def _unsupport_ukraine():
    
    w=get_workbench()
    w._toolbar_buttons.get('SupportUkraine').destroy()
    # for index in range(w._menus["help"].index("end")):
    #     menu_info = w._menus["help"].entryconfig(index)
        
    #     print(menu_info)

    
    w._menus["help"].delete("end")#ukraine
    w._menus["help"].delete("end")#separator


def _support_palestine():  
    webbrowser.open("https://ar.wikipedia.org/wiki/%D8%B9%D9%85%D9%84%D9%8A%D8%A9_%D8%B7%D9%88%D9%81%D8%A7%D9%86_%D8%A7%D9%84%D8%A3%D9%82%D8%B5%D9%89")
    


    
